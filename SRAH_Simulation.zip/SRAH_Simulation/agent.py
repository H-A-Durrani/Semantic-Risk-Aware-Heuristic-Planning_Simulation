"""
agent.py
--------
Agent class: wraps a planner and steps through the environment one cell at
a time, tracking statistics (steps, replans, direction changes) used in the
final comparison plots.
"""

from config import DYNAMIC_MOVE_INTERVAL, MAX_STEPS


class Agent:
    """
    Simulated robot agent.

    Parameters
    ----------
    name    : str         -- "SRAH", "BFS", or "Greedy" (affects replan logic)
    planner : callable    -- planners.astar_srah | bfs_with_replanning | greedy_no_replan
    world   : GridWorld   -- the environment this agent navigates
    """

    def __init__(self, name, planner, world):
        self.name    = name
        self.planner = planner
        self.world   = world
        self.pos     = world.start
        self.goal    = world.goal

        self.path          = []
        self.trail         = [world.start]
        self.visited_cells = set()

        self.steps         = 0
        self.replans       = 0
        self.direction_chg = 0
        self._last_dir     = None

        self.success = False
        self.failed  = False
        self.done    = False
        self._step_ctr = 0

        self._replan(initial=True)

    # -------------------------------------------------------------------------
    #  Internal helpers
    # -------------------------------------------------------------------------

    def _replan(self, initial=False):
        """Call the planner from the current position and store the new path."""
        path, vis = self.planner(self.world, self.pos, self.goal)
        self.path = path if path else []
        self.visited_cells.update(vis)
        if not initial and path:
            self.replans += 1

    # -------------------------------------------------------------------------
    #  Simulation step
    # -------------------------------------------------------------------------

    def step(self):
        """
        Advance the agent by one simulation tick.

        Tick logic:
          1. Every DYNAMIC_MOVE_INTERVAL ticks: move dynamic obstacles.
             If the next planned cell is now blocked, fail (for SRAH/BFS the
             controller catches this and triggers a replan before calling step
             again; Greedy just fails).
          2. Replan if the path is empty or exhausted (SRAH / BFS only).
          3. Move to the next cell in the path.
          4. Record direction change and update stats.
        """
        if self.done:
            return

        self._step_ctr += 1

        # --- Dynamic obstacle movement ---
        if self._step_ctr % DYNAMIC_MOVE_INTERVAL == 0:
            self.world.move_dynamic_obstacles()
            if (self.name != "Greedy"
                    and self.path and len(self.path) > 1
                    and self.world.is_blocked(*self.path[1])):
                self.failed = True
                self.done   = True
                return

        # --- Ensure we have a valid path ---
        if not self.path or len(self.path) < 2:
            if self.name == "Greedy":
                self.failed = self.done = True
                return
            self._replan()
            if not self.path:
                self.failed = self.done = True
                return

        nxt = self.path[1]

        # --- Handle blocked next step ---
        if self.world.is_blocked(*nxt):
            if self.name == "Greedy":
                self.failed = self.done = True
                return
            self._replan()
            if not self.path or len(self.path) < 2:
                self.failed = self.done = True
                return
            nxt = self.path[1]

        # --- Track direction changes ---
        cur_dir = (nxt[0] - self.pos[0], nxt[1] - self.pos[1])
        if self._last_dir is not None and cur_dir != self._last_dir:
            self.direction_chg += 1
        self._last_dir = cur_dir

        # --- Move ---
        self.pos   = nxt
        self.path  = self.path[1:]
        self.trail.append(self.pos)
        self.steps += 1

        # --- Termination ---
        if self.pos == self.goal:
            self.success = self.done = True
            return
        if self.steps >= MAX_STEPS:
            self.failed = self.done = True
