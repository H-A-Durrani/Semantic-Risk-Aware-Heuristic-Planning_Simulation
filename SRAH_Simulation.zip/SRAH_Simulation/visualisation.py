"""
visualisation.py
----------------
Rendering helpers for the live simulation window:

  render_panel      -- draws one agent's grid view (obstacles, risk overlay,
                       trail, path, agent position)
  render_live_stats -- draws the grouped bar chart comparing the three
                       algorithms across completed trials
"""

import numpy as np

from config import (
    GRID_SIZE,
    C_BG, C_WALL, C_DYN, C_START, C_GOAL,
    C_PATH, C_TRAIL, C_VISITED, C_AGENT,
    C_RISK_VHI, C_RISK_HI, C_RISK_MID,
    NUM_TRIALS,
)


# =============================================================================
#  Per-agent grid panel
# =============================================================================

def render_panel(ax, world, agent, title):
    """
    Render one agent's grid panel onto *ax*.

    Layers (bottom to top):
      background -> risk overlay (SRAH only) -> visited cells -> trail ->
      planned path -> static walls -> dynamic obstacles -> start/goal -> agent
    """
    ax.clear()
    omap = world.get_full_map()
    img  = np.tile(C_BG, (GRID_SIZE, GRID_SIZE, 1))

    # --- Risk overlay (SRAH only) ---
    if agent.name == "SRAH":
        phi = world.compute_phi()
        mx  = phi.max() + 1e-8
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                if omap[r, c] == 0 and phi[r, c] > 0:
                    v = phi[r, c] / mx
                    if   v > 0.75: img[r, c] = img[r, c] * 0.20 + C_RISK_VHI * 0.80
                    elif v > 0.45: img[r, c] = img[r, c] * 0.35 + C_RISK_HI  * 0.65
                    else:          img[r, c] = img[r, c] * 0.55 + C_RISK_MID  * 0.45

    # --- Visited cells ---
    for r, c in agent.visited_cells:
        if omap[r, c] == 0 and (r, c) != world.start and (r, c) != world.goal:
            img[r, c] = C_VISITED

    # --- Agent trail ---
    for r, c in agent.trail:
        if (r, c) != world.start and (r, c) != world.goal:
            img[r, c] = C_TRAIL

    # --- Planned path ---
    if agent.path:
        for r, c in agent.path:
            if (r, c) != world.start and (r, c) != world.goal:
                img[r, c] = C_PATH

    # --- Static walls ---
    for r in range(GRID_SIZE):
        for c in range(GRID_SIZE):
            if omap[r, c] == 1:
                img[r, c] = C_WALL

    # --- Dynamic obstacles ---
    for r, c in world.dynamic_obstacles:
        img[r, c] = C_DYN

    # --- Start / Goal / Agent ---
    img[world.start] = C_START
    img[world.goal]  = C_GOAL
    img[agent.pos]   = C_AGENT

    ax.imshow(img, interpolation='nearest', aspect='equal')

    # Grid lines
    for i in range(GRID_SIZE + 1):
        ax.axhline(i - 0.5, color='#0d0d1a', lw=0.3)
        ax.axvline(i - 0.5, color='#0d0d1a', lw=0.3)

    # Status colour & label
    if   agent.success: status, sc = "SUCCESS", "#2ecc71"
    elif agent.failed:  status, sc = "FAILED",  "#e74c3c"
    else:               status, sc = "RUNNING", "#f39c12"

    ax.set_title(
        f"{title}\n{status}  Steps:{agent.steps}  Replans:{agent.replans}",
        fontsize=9, fontweight='bold', color=sc, fontfamily='monospace', pad=5
    )
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_facecolor('#0d0d1a')
    for sp in ax.spines.values():
        sp.set_edgecolor('#2a2a4a')
        sp.set_linewidth(1.2)


# =============================================================================
#  Live statistics bar chart
# =============================================================================

def render_live_stats(ax, results, trial_num):
    """
    Draw a grouped bar chart comparing SRAH, BFS, and Greedy across four
    metrics: success rate, average steps, average replans, average direction
    changes (successful runs only for the last metric).
    """
    ax.clear()
    ax.set_facecolor('#0d0d1a')

    algs   = ["SRAH", "BFS", "Greedy"]
    colors = ["#f0d060", "#40e0e0", "#ff6090"]
    n      = max(trial_num, 1)

    # Aggregate metrics
    sr = [sum(r["success"] for r in results[a]) / n * 100 for a in algs]
    st = [
        np.mean([r["steps"]   for r in results[a]]) if results[a] else 0
        for a in algs
    ]
    rp = [
        np.mean([r["replans"] for r in results[a]]) if results[a] else 0
        for a in algs
    ]
    dc = []
    for a in algs:
        ok = [r["direction_chg"] for r in results[a] if r["success"]]
        dc.append(np.mean(ok) if ok else 0)

    x, w = np.arange(3), 0.20
    b1 = ax.bar(x - w * 1.5, sr, w, label='Success %',
                color=[c + "cc" for c in colors], edgecolor='white', lw=0.5)
    b2 = ax.bar(x - w * 0.5, st, w, label='Avg Steps',
                color=[c + "88" for c in colors], edgecolor='white', lw=0.5)
    b3 = ax.bar(x + w * 0.5, rp, w, label='Avg Replans',
                color=[c + "55" for c in colors], edgecolor='white', lw=0.5)
    b4 = ax.bar(x + w * 1.5, dc, w, label='Avg DirChg',
                color=[c + "33" for c in colors], edgecolor='white', lw=0.5)

    # Value labels above each bar
    for bar in list(b1) + list(b2) + list(b3) + list(b4):
        h = bar.get_height()
        if h > 0.5:
            ax.text(
                bar.get_x() + bar.get_width() / 2, h + 0.3, f'{h:.1f}',
                ha='center', va='bottom', fontsize=6.5,
                color='white', fontfamily='monospace'
            )

    ax.set_xticks(x)
    ax.set_xticklabels(
        algs, fontsize=10, fontweight='bold',
        fontfamily='monospace', color='#a0a0cc'
    )
    ax.tick_params(colors='#a0a0cc')
    ax.set_ylabel('Value', color='#a0a0cc', fontfamily='monospace', fontsize=9)
    ax.set_title(
        f'Live Stats  --  {trial_num}/{NUM_TRIALS} trials',
        color='#a0a0cc', fontfamily='monospace', fontsize=9
    )
    ax.legend(
        fontsize=7, facecolor='#1a1a2e', edgecolor='#333355',
        labelcolor='white', loc='upper right'
    )
    for sp in ['bottom', 'left']:
        ax.spines[sp].set_color('#333355')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
