"""
main.py
-------
Entry point for the SRAH vs BFS vs Greedy simulation.

Run with:
    python main.py

Dependencies:
    pip install matplotlib numpy
"""

import matplotlib
# Try common backends in order; fall back to non-interactive Agg
for _be in ['TkAgg', 'Qt5Agg', 'MacOSX', 'Agg']:
    try:
        matplotlib.use(_be)
        break
    except Exception:
        pass

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec

from config import (
    NUM_TRIALS, MAX_STEPS, ANIMATION_DELAY,
    C_AGENT, C_START, C_GOAL, C_WALL, C_DYN,
    C_PATH, C_TRAIL, C_VISITED, C_RISK_VHI, C_RISK_HI, C_RISK_MID,
)
from grid_world   import GridWorld
from planners     import astar_srah, bfs_with_replanning, greedy_no_replan
from agent        import Agent
from visualisation import render_panel, render_live_stats


# =============================================================================
#  Main simulation loop
# =============================================================================

def run_simulation():
    results = {"SRAH": [], "BFS": [], "Greedy": []}

    # --- Figure layout -------------------------------------------------------
    plt.style.use('dark_background')
    fig = plt.figure(figsize=(20, 9), facecolor='#0a0a14')
    gs  = gridspec.GridSpec(
        2, 4, figure=fig,
        width_ratios=[1, 1, 1, 1.4],
        height_ratios=[1, 1],
        hspace=0.48, wspace=0.28
    )

    ax_srah   = fig.add_subplot(gs[0, 0])
    ax_bfs    = fig.add_subplot(gs[0, 1])
    ax_greedy = fig.add_subplot(gs[0, 2])
    ax_stats  = fig.add_subplot(gs[:, 3])

    # Legend panel
    ax_legend = fig.add_subplot(gs[1, 0])
    ax_legend.set_facecolor('#0d0d1a')
    ax_legend.axis('off')
    ax_legend.legend(
        handles=[
            mpatches.Patch(color=C_AGENT,    label='Agent'),
            mpatches.Patch(color=C_START,    label='Start'),
            mpatches.Patch(color=C_GOAL,     label='Goal'),
            mpatches.Patch(color=C_WALL,     label='Static obstacle'),
            mpatches.Patch(color=C_DYN,      label='Dynamic obstacle'),
            mpatches.Patch(color=C_PATH,     label='Planned path'),
            mpatches.Patch(color=C_TRAIL,    label='Agent trail'),
            mpatches.Patch(color=C_VISITED,  label='Explored cells'),
            mpatches.Patch(color=C_RISK_VHI, label='Very-high risk (SRAH)'),
            mpatches.Patch(color=C_RISK_HI,  label='High risk (SRAH)'),
            mpatches.Patch(color=C_RISK_MID, label='Mid risk (SRAH)'),
        ],
        loc='center', fontsize=7.5, facecolor='#1a1a2e', edgecolor='#444466',
        labelcolor='white', framealpha=0.95, title='Legend', title_fontsize=8
    )

    # Progress text panel
    ax_prog = fig.add_subplot(gs[1, 1:3])
    ax_prog.set_facecolor('#0d0d1a')
    ax_prog.axis('off')
    prog_text = ax_prog.text(
        0.5, 0.5, '', ha='center', va='center',
        fontsize=10, color='#c0c0e0', fontfamily='monospace',
        transform=ax_prog.transAxes
    )

    fig.suptitle(
        'SRAH vs BFS vs Greedy  |  Semantic Risk-Aware Heuristic Planning',
        fontsize=12, fontweight='bold', color='#a0a0cc',
        fontfamily='monospace', y=0.99
    )

    plt.ion()
    plt.show()

    # --- Trial loop ----------------------------------------------------------
    for trial in range(NUM_TRIALS):
        seed = trial * 31 + 17

        w_s = GridWorld(seed=seed)
        w_b = GridWorld(seed=seed)
        w_g = GridWorld(seed=seed)

        a_s = Agent("SRAH",   astar_srah,          w_s)
        a_b = Agent("BFS",    bfs_with_replanning, w_b)
        a_g = Agent("Greedy", greedy_no_replan,    w_g)

        agents  = [a_s, a_b, a_g]
        worlds  = [w_s, w_b, w_g]
        ax_list = [ax_srah, ax_bfs, ax_greedy]
        titles  = ["SRAH (Risk-Aware A*)", "BFS + Replanning", "Greedy (No Replan)"]

        step = 0
        while not all(a.done for a in agents) and step < MAX_STEPS:
            for a in agents:
                if not a.done:
                    a.step()

            if step % 2 == 0:
                for ax_, ag_, wo_, ti_ in zip(ax_list, agents, worlds, titles):
                    render_panel(ax_, wo_, ag_, ti_)
                prog_text.set_text(
                    f'Trial {trial + 1} / {NUM_TRIALS}   Step {step}\n'
                    f'SRAH   {"OK" if a_s.success else "X" if a_s.failed else "..."}'
                    f'   BFS {"OK" if a_b.success else "X" if a_b.failed else "..."}'
                    f'   Greedy {"OK" if a_g.success else "X" if a_g.failed else "..."}'
                )
                render_live_stats(ax_stats, results, trial)
                fig.canvas.draw()
                fig.canvas.flush_events()
                plt.pause(ANIMATION_DELAY)

            step += 1

        # Final render of this trial
        for ax_, ag_, wo_, ti_ in zip(ax_list, agents, worlds, titles):
            render_panel(ax_, wo_, ag_, ti_)
        render_live_stats(ax_stats, results, trial + 1)
        fig.canvas.draw()
        fig.canvas.flush_events()
        plt.pause(15)

        for ag_, key_ in zip(agents, ["SRAH", "BFS", "Greedy"]):
            results[key_].append({
                "success":       ag_.success,
                "steps":         ag_.steps,
                "replans":       ag_.replans,
                "direction_chg": ag_.direction_chg,
            })

    print("Simulation complete.\n")


# =============================================================================
if __name__ == "__main__":
    run_simulation()
