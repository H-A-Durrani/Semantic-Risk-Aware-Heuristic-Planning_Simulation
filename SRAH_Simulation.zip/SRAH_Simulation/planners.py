"""
planners.py
-----------
The three path-planning algorithms compared in the simulation:

  astar_srah          -- SRAH: Weighted A* with semantic phi(s) edge cost
  bfs_with_replanning -- Standard BFS (uniform cost, no semantic bias)
  greedy_no_replan    -- Pure greedy best-first (Manhattan heuristic only)

All planners share the same interface:
    planner(world, start, goal) -> (path | None, visited_set)
"""

import heapq
from collections import deque

from config import ASTAR_W


# =============================================================================
#  Shared heuristic
# =============================================================================

def manhattan(a, b):
    """Manhattan distance between two grid cells."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


# =============================================================================
#  SRAH: Semantic Risk-Aware Heuristic (Weighted A*)
# =============================================================================

def astar_srah(world, start, goal):
    """
    SRAH planner -- Paper Eq.(1) extended.

    Edge cost:  c(s, s') = 1 + phi(s')
    f-score:    f(s)     = g(s) + ASTAR_W * h(s)

    Routes around both structural bottlenecks and dynamic-obstacle hotspots
    by incorporating the pre-computed semantic risk field phi.
    """
    phi      = world.compute_phi()
    open_set = []
    heapq.heappush(open_set, (0.0, start))
    came_from = {}
    g_score   = {start: 0.0}
    visited   = set()

    while open_set:
        _, cur = heapq.heappop(open_set)
        if cur in visited:
            continue
        visited.add(cur)
        if cur == goal:
            path = []
            while cur in came_from:
                path.append(cur)
                cur = came_from[cur]
            path.append(start)
            return list(reversed(path)), visited

        for nb in world.neighbors(*cur):
            ng = g_score[cur] + 1.0 + phi[nb[0], nb[1]]
            if nb not in g_score or ng < g_score[nb]:
                g_score[nb]   = ng
                came_from[nb] = cur
                heapq.heappush(open_set,
                               (ng + ASTAR_W * manhattan(nb, goal), nb))

    return None, visited


# =============================================================================
#  BFS with Replanning
# =============================================================================

def bfs_with_replanning(world, start, goal):
    """
    Standard BFS -- uniform cost, zero semantic bias.

    Called fresh each time the agent needs to replan (i.e. whenever the
    next step is blocked by a dynamic obstacle).
    """
    queue   = deque([(start, [start])])
    visited = {start}
    while queue:
        cur, path = queue.popleft()
        if cur == goal:
            return path, visited
        for nb in world.neighbors(*cur):
            if nb not in visited:
                visited.add(nb)
                queue.append((nb, path + [nb]))
    return None, visited


# =============================================================================
#  Greedy Best-First (no replanning)
# =============================================================================

def greedy_no_replan(world, start, goal):
    """
    Pure greedy best-first search using the Manhattan heuristic.

    The agent commits to the initial plan and does *not* replan when blocked,
    serving as the weakest baseline in the comparison.
    """
    open_set  = [(manhattan(start, goal), start)]
    came_from = {}
    visited   = set()

    while open_set:
        _, cur = heapq.heappop(open_set)
        if cur in visited:
            continue
        visited.add(cur)
        if cur == goal:
            path = []
            while cur in came_from:
                path.append(cur)
                cur = came_from[cur]
            path.append(start)
            return list(reversed(path)), visited
        for nb in world.neighbors(*cur):
            if nb not in visited:
                came_from[nb] = cur
                heapq.heappush(open_set, (manhattan(nb, goal), nb))

    return None, visited
