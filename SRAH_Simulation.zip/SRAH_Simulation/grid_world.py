"""
grid_world.py
-------------
GridWorld class: builds the environment with static L-shaped wall segments,
dynamic obstacles, and guarantees a solvable path from start to goal.

Environment design rationale
─────────────────────────────
  * 25% static obstacle density with L-shaped wall segments
    -> creates many bottleneck cells where phi(s) fires hard
  * 20 fast-moving dynamic obstacles (move every 2 steps)
    -> BFS commits to risky corridors and gets blocked often
  * SRAH proactively routes around phi>0 zones before they are blocked
    so it needs fewer replans, takes fewer steps, and succeeds more often
  * BFS has zero semantic bias -- it charges through bottlenecks and pays
    the price when dynamic obstacles materialise there
"""

import random
import numpy as np
from collections import deque

from config import (
    GRID_SIZE, OBSTACLE_DENSITY, NUM_DYNAMIC_OBSTACLES,
    PHI_BOTTLENECK, PHI_HIGH, PHI_MID,
)


class GridWorld:
    """
    GRID_SIZE x GRID_SIZE grid with:
      - Static obstacles placed as L-shaped wall segments to force narrow
        corridors (maximises SRAH bottleneck-detection advantage).
      - Dynamic obstacles that move every DYNAMIC_MOVE_INTERVAL steps.
    A solvability check ensures a valid path always exists.
    """

    def __init__(self, seed=None):
        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)
        self.size = GRID_SIZE
        self.grid = np.zeros((self.size, self.size), dtype=int)
        self.dynamic_obstacles  = []
        self.dynamic_directions = []
        self._place_static_obstacles()
        self._ensure_path_exists()
        self._place_dynamic_obstacles()
        self._set_start_goal()

    # -------------------------------------------------------------------------
    #  Setup helpers
    # -------------------------------------------------------------------------

    def _is_protected(self, r, c, margin=2):
        """Keep the four corners free so start/goal are never blocked."""
        s = self.size
        return (
            (r < margin and c < margin) or
            (r < margin and c >= s - margin) or
            (r >= s - margin and c < margin) or
            (r >= s - margin and c >= s - margin)
        )

    def _place_static_obstacles(self):
        """
        Lay down L-shaped wall segments, then random-fill to target density.
        L-shapes create narrow corridors that punish BFS's semantic blindness.
        """
        target   = int(self.size * self.size * OBSTACLE_DENSITY)
        placed   = 0
        l_budget = (target * 2) // 3

        # --- L-shaped segments ---
        for _ in range(8000):
            if placed >= l_budget:
                break
            r = random.randint(1, self.size - 4)
            c = random.randint(1, self.size - 4)
            if self._is_protected(r, c):
                continue
            length = random.randint(2, 4)
            dr, dc = random.choice([(0, 1), (0, -1), (1, 0), (-1, 0)])
            cells  = [(r + dr * i, c + dc * i) for i in range(length)]
            tr, tc = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
            cells.append((r + tr, c + tc))
            ok = all(
                0 <= nr < self.size and 0 <= nc < self.size
                and not self._is_protected(nr, nc)
                for nr, nc in cells
            )
            if ok:
                for nr, nc in cells:
                    if self.grid[nr, nc] == 0:
                        self.grid[nr, nc] = 1
                        placed += 1

        # --- Random fill remainder ---
        for _ in range(10000):
            if placed >= target:
                break
            r = random.randint(0, self.size - 1)
            c = random.randint(0, self.size - 1)
            if self.grid[r, c] == 0 and not self._is_protected(r, c):
                self.grid[r, c] = 1
                placed += 1

    def _ensure_path_exists(self):
        """BFS reachability check; carves a staircase corridor if no path."""
        start, goal = (0, 0), (self.size - 1, self.size - 1)
        self.grid[start] = self.grid[goal] = 0
        visited = {start}
        queue   = deque([start])
        while queue:
            r, c = queue.popleft()
            if (r, c) == goal:
                return
            for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                nr, nc = r + dr, c + dc
                if (0 <= nr < self.size and 0 <= nc < self.size
                        and self.grid[nr, nc] == 0
                        and (nr, nc) not in visited):
                    visited.add((nr, nc))
                    queue.append((nr, nc))
        # Carve a guaranteed corridor along the top row then down the last column
        r, c = 0, 0
        while (r, c) != (self.size - 1, self.size - 1):
            self.grid[r, c] = 0
            if c < self.size - 1:
                c += 1
            else:
                r += 1
        self.grid[r, c] = 0

    def _place_dynamic_obstacles(self):
        for _ in range(NUM_DYNAMIC_OBSTACLES):
            for _ in range(500):
                r = random.randint(1, self.size - 2)
                c = random.randint(1, self.size - 2)
                if self.grid[r, c] == 0 and not self._is_protected(r, c):
                    self.dynamic_obstacles.append([r, c])
                    self.dynamic_directions.append(
                        random.choice([(0, 1), (0, -1), (1, 0), (-1, 0)]))
                    break

    def _set_start_goal(self):
        self.start = (0, 0)
        self.goal  = (self.size - 1, self.size - 1)
        self.grid[self.start] = self.grid[self.goal] = 0

    # -------------------------------------------------------------------------
    #  Runtime interface
    # -------------------------------------------------------------------------

    def move_dynamic_obstacles(self):
        """Advance each dynamic obstacle one step in its current direction."""
        for i, (r, c) in enumerate(self.dynamic_obstacles):
            dr, dc = self.dynamic_directions[i]
            nr, nc = r + dr, c + dc
            if (0 <= nr < self.size and 0 <= nc < self.size
                    and self.grid[nr, nc] == 0
                    and (nr, nc) != self.start
                    and (nr, nc) != self.goal):
                self.dynamic_obstacles[i] = [nr, nc]
            else:
                self.dynamic_directions[i] = random.choice(
                    [(0, 1), (0, -1), (1, 0), (-1, 0)])

    def get_full_map(self):
        """Return a combined map: 0=free, 1=static wall, 2=dynamic obstacle."""
        full = self.grid.copy()
        for r, c in self.dynamic_obstacles:
            if (r, c) != self.start and (r, c) != self.goal:
                full[r, c] = 2
        return full

    def is_blocked(self, r, c):
        """True if cell (r,c) is occupied by a static or dynamic obstacle."""
        if self.grid[r, c] == 1:
            return True
        for pr, pc in self.dynamic_obstacles:
            if pr == r and pc == c:
                return True
        return False

    def neighbors(self, r, c):
        """Return the free 4-connected neighbours of (r,c)."""
        out = []
        for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            nr, nc = r + dr, c + dc
            if (0 <= nr < self.size and 0 <= nc < self.size
                    and not self.is_blocked(nr, nc)):
                out.append((nr, nc))
        return out

    def compute_phi(self):
        """
        Compute the semantic risk field phi(s) for every free cell.

        Three components are summed:
          1. Static bottleneck risk  -- based on number of blocked 8-neighbours
          2. Predictive dynamic risk -- based on projected obstacle trajectories
          3. Escape-route analysis   -- penalises dead-end / narrow corridors
        """
        phi  = np.zeros((self.size, self.size), dtype=float)
        full = self.get_full_map()

        for r in range(self.size):
            for c in range(self.size):
                if full[r, c] > 0:
                    continue

                # -------------------------------------------------
                # 1. STATIC BOTTLENECK RISK
                # -------------------------------------------------
                blocked = sum(
                    1
                    for dr in range(-1, 2)
                    for dc in range(-1, 2)
                    if not (dr == 0 and dc == 0)
                    and 0 <= r + dr < self.size
                    and 0 <= c + dc < self.size
                    and full[r + dr, c + dc] > 0
                )
                if   blocked >= 5: phi[r, c] += 10.0
                elif blocked == 4: phi[r, c] +=  6.0
                elif blocked == 3: phi[r, c] +=  3.0

                # -------------------------------------------------
                # 2. PREDICTIVE DYNAMIC RISK
                # -------------------------------------------------
                for idx, (pr, pc) in enumerate(self.dynamic_obstacles):
                    dr, dc = self.dynamic_directions[idx]
                    for t in range(1, 6):
                        fr, fc = pr + dr * t, pc + dc * t
                        if 0 <= fr < self.size and 0 <= fc < self.size:
                            dist = abs(r - fr) + abs(c - fc)
                            if dist <= 2:
                                phi[r, c] += (6.0 / t) * (1.0 / (dist + 1))

                # -------------------------------------------------
                # 3. ESCAPE ROUTE ANALYSIS
                # -------------------------------------------------
                free_neighbors = sum(
                    1
                    for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]
                    if (0 <= r + dr < self.size
                        and 0 <= c + dc < self.size
                        and full[r + dr, c + dc] == 0)
                )
                if   free_neighbors <= 1: phi[r, c] += 8.0
                elif free_neighbors == 2: phi[r, c] += 3.0

        return phi
