"""
config.py
---------
Central configuration: simulation parameters, SRAH cost constants, and colours.
Edit values here to tune the simulation without touching any other file.
"""

import numpy as np

# =============================================================================
#  SIMULATION PARAMETERS
# =============================================================================

GRID_SIZE             = 45
OBSTACLE_DENSITY      = 0.25    # 25% -- forces genuine bottlenecks
NUM_DYNAMIC_OBSTACLES = 20      # fast movers
DYNAMIC_MOVE_INTERVAL = 2       # move every 2 steps (very aggressive)
MAX_STEPS             = 450
ANIMATION_DELAY       = 0.05    # seconds per frame
NUM_TRIALS            = 10

# =============================================================================
#  SRAH SEMANTIC COST  (Paper Eq.(1) extended)
# =============================================================================

PHI_BOTTLENECK   = 8.5   # A(s) >= 4 blocked neighbours
PHI_HIGH         = 5.0   # A(s) == 3
PHI_MID          = 1.8   # A(s) == 2
PHI_LOW          = 0.0   # A(s) <= 1
ASTAR_W          = 1.0   # weighted A* factor

# Additional dynamic-obstacle proximity penalty baked into phi
DYN_PROX_PENALTY = 1.5   # cost per dyn-obstacle within Manhattan dist 2

# =============================================================================
#  COLOURS  (RGB arrays in [0, 1])
# =============================================================================

C_BG        = np.array([0.06, 0.06, 0.11])
C_WALL      = np.array([0.72, 0.18, 0.18])
C_DYN       = np.array([1.00, 0.52, 0.08])
C_START     = np.array([0.18, 0.82, 0.38])
C_GOAL      = np.array([0.08, 0.62, 1.00])
C_PATH      = np.array([0.95, 0.90, 0.28])
C_TRAIL     = np.array([0.38, 0.48, 0.78])
C_VISITED   = np.array([0.16, 0.20, 0.35])
C_AGENT     = np.array([1.00, 1.00, 1.00])
C_RISK_VHI  = np.array([0.65, 0.08, 0.08])
C_RISK_HI   = np.array([0.45, 0.10, 0.10])
C_RISK_MID  = np.array([0.28, 0.08, 0.08])
