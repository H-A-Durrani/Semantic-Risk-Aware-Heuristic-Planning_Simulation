# SRAH vs BFS vs Greedy — Real-Time Path Planning Simulation

**Paper:** Semantic Risk-Aware Heuristic Planning for Robotic Navigation in Dynamic Environments: An LLM-Inspired Approach  
**arXiv:** [2605.02862](https://arxiv.org/abs/2605.02862)  
**Author:** Hamza Ahmed Durrani

---

## Overview

This simulation compares three path-planning algorithms on a dynamic grid world:

| Algorithm | Description |
|-----------|-------------|
| **SRAH** | Weighted A\* with a semantic risk field φ(s) that penalises bottlenecks and predicted dynamic-obstacle zones |
| **BFS** | Standard breadth-first search — replans whenever blocked, but has zero semantic awareness |
| **Greedy** | Pure greedy best-first search — commits to the initial plan, no replanning |

The environment is designed so that SRAH's semantic awareness provides a genuine, measurable advantage:
- **25% static obstacle density** with L-shaped wall segments → narrow bottleneck corridors
- **20 fast-moving dynamic obstacles** (move every 2 steps) → BFS gets caught in risky corridors
- SRAH proactively routes around `φ > 0` zones before they become blocked

---

## Project Structure

```
srah_simulation/
├── main.py            # Entry point — run this file
├── config.py          # All tunable parameters and colour constants
├── grid_world.py      # GridWorld class (static + dynamic obstacles, φ field)
├── planners.py        # astar_srah, bfs_with_replanning, greedy_no_replan
├── agent.py           # Agent class (steps through environment, tracks stats)
├── visualisation.py   # render_panel, render_live_stats (matplotlib rendering)
└── README.md
```

---

## Installation

```bash
pip install matplotlib numpy
```

## Usage

```bash
cd srah_simulation
python main.py
```

---

## Configuration

All simulation parameters live in `config.py`:

| Parameter | Default | Description |
|-----------|---------|-------------|
| `GRID_SIZE` | 45 | Grid dimensions (N × N) |
| `OBSTACLE_DENSITY` | 0.25 | Fraction of cells that are static obstacles |
| `NUM_DYNAMIC_OBSTACLES` | 20 | Number of moving obstacles |
| `DYNAMIC_MOVE_INTERVAL` | 2 | Steps between dynamic obstacle movements |
| `MAX_STEPS` | 450 | Maximum steps before a trial is failed |
| `NUM_TRIALS` | 10 | Number of independent trials to run |
| `ANIMATION_DELAY` | 0.05 | Seconds per rendered frame |
| `ASTAR_W` | 1.0 | Weighted A\* inflation factor |

---

## Metrics Tracked

- **Success rate** — percentage of trials where the agent reached the goal
- **Avg steps** — average number of steps taken per trial
- **Avg replans** — average number of times the agent had to replan
- **Avg direction changes** — path smoothness proxy (successful runs only)
